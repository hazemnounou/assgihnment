public class GroceryOrder {
    private String itemname;
    private int quan;
    private double priceperu;
    public GroceryOrder(String itemname , double priceperu){
        this.itemname=itemname;
        this.priceperu=priceperu;
    }
    public void setQuan(int quantity){
        this.quan=quantity;

    }
    public double getCost(){
        return priceperu*quan;
    }

}
