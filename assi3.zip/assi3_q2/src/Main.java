import java.util.ArrayList;
import java.util.Collections;

public class Main {

    ArrayList<Integer> arr = new ArrayList<Integer>();

    arr.add(50);

    public static Integer max(ArrayList<Integer>list){
        if(list.isEmpty()){
            return null;
        }
        return Collections.max(list);


    }
}